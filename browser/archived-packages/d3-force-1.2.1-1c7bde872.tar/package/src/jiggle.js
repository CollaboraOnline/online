export default function() {
  return (Math.random() - 0.5) * 1e-6;
}
