var convert = require('./convert'),
    func = convert('flattenDepth', require('../flattenDepth'));

func.placeholder = require('./placeholder');
module.exports = func;
