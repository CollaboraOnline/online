## 0.0.4
- Fix bugs, Node exports
- Add tests
## 0.0.1
- Created basic decompressor