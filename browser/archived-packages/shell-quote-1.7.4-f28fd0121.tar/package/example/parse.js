'use strict';

var parse = require('../').parse;
var xs = parse('a "b c" \\$def \'it\\\'s great\'');
console.dir(xs);
