# Installation
> `npm install --save @types/mdast`

# Summary
This package contains type definitions for Mdast (https://github.com/syntax-tree/mdast).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast.

### Additional Details
 * Last updated: Mon, 23 Aug 2021 20:18:29 GMT
 * Dependencies: [@types/unist](https://npmjs.com/package/@types/unist)
 * Global values: none

# Credits
These definitions were written by [Christian Murphy](https://github.com/ChristianMurphy), [Jun Lu](https://github.com/lujun2), [Remco Haszing](https://github.com/remcohaszing), and [Titus Wormer](https://github.com/wooorm).
