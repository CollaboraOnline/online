'use strict';

module.exports = input => Object.prototype.toString.call(input) === '[object RegExp]';
