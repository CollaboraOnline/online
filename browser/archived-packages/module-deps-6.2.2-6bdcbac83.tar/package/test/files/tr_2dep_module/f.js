module.exports = function (x) { return x + BBB }
