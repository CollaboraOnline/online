module.exports = function () {
    return 'baz';
};