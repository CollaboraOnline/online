var bar = require('../bar/bar.js');
var baz = require('./baz/baz.js');

module.exports = function () {
    return 'foo';
};