module.exports = function () {
    return 'bar2';
};