# 3.0.0

-   Added: `function-calc-no-invalid` rule.
-   Removed: `stylelint` < 10.1.0 from peer dependencies. stylelint@10.1.0+ is required now.

# 2.2.0

-   Added: `stylelint@10` to peer dependency range.

# 2.1.0

-   Added: `stylelint@9` to peer dependency range.

# 2.0.1

-   Removed: `declaration-block-no-redundant-longhand-properties` rule. This time it is actually removed.

# 2.0.0

-   Removed: `declaration-block-no-redundant-longhand-properties` rule.
-   Removed: `shorthand-property-no-redundant-values` rule.
-   Added: `font-family-no-missing-generic-family-keyword` rule.
-   Added: `no-descending-specificity` rule.
-   Added: `no-duplicate-at-import-rules` rule.
-   Added: `no-duplicate-selectors` rule.

# 1.0.0

-   Use `stylelint@8`.

# 0.1.0

-   Initial release
