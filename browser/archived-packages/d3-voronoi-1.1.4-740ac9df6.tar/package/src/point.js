export function x(d) {
  return d[0];
}

export function y(d) {
  return d[1];
}
