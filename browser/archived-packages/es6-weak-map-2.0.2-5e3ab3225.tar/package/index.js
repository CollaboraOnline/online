'use strict';

module.exports = require('./is-implemented')() ? WeakMap : require('./polyfill');
