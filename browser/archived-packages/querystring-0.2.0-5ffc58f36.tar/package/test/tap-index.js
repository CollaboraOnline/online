"use strict";

require("retape")(require("./index"))