## vex-dialog

A dialog plugin for [vex](https://github.com/bbatliner/vex). Drop-in replacement for the browser's `alert`, `confirm`, and `prompt`.

Docs available on [GitHub](https://github.com/HubSpot/vex/tree/master/docs) or on [the web](http://github.hubspot.com/vex/).

[![js-standard-style](https://cdn.rawgit.com/feross/standard/master/badge.svg)](https://github.com/feross/standard)
