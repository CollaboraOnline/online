export default function(update) {
  return new Array(update.length);
}
