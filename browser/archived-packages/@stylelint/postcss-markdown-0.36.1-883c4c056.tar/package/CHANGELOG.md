# Changelog

## 0.36.1

- Fixed: outdated dependencies

## Previous changes

See [postcss-markdown releases](https://github.com/gucong3000/postcss-markdown).
