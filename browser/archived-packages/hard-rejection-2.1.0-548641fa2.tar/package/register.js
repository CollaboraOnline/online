'use strict';
require('.')();
