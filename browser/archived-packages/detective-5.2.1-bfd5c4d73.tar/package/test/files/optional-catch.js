try {
    require;
} catch {
}
