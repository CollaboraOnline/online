export declare const encodeXML: (data: string) => string;
export declare const encodeHTML: (data: string) => string;
export declare function escape(data: string): string;
//# sourceMappingURL=encode.d.ts.map