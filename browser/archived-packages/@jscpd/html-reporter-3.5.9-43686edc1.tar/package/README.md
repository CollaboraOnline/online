# `html-reporter`

> TODO: description

## Usage

```
const htmlReporter = require('html-reporter');

// TODO: DEMONSTRATE API
```
