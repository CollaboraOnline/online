## 3.3.0-rc.3 (2020-05-04)




## 3.3.0-rc.3 (2020-05-02)

* v3.3.0-rc.3 ([9f388ff](https://github.com/kucherenko/jscpd/commit/9f388ff))
* docs: ✏️ update README for the packages ([76492e6](https://github.com/kucherenko/jscpd/commit/76492e6))
* feat: 🎸 start redis store development ([c0a1584](https://github.com/kucherenko/jscpd/commit/c0a1584))
* refactor: 💡 change imports in interfaces ([f72e3e0](https://github.com/kucherenko/jscpd/commit/f72e3e0))
* refactor: 💡 remove cyclic dependency between core and tokenizer ([6615825](https://github.com/kucherenko/jscpd/commit/6615825))
* chore: 🤖 add tool for changing package.json before publishing ([fb9c7ec](https://github.com/kucherenko/jscpd/commit/fb9c7ec))
* chore: 🤖 change npm script to yarn ([3729bf9](https://github.com/kucherenko/jscpd/commit/3729bf9))
* chore: 🤖 change package json ([205136f](https://github.com/kucherenko/jscpd/commit/205136f))
* chore: 🤖 fix issue with yarncompile ([44eef97](https://github.com/kucherenko/jscpd/commit/44eef97))



## 3.3.0-rc.2 (2020-04-29)

* v3.3.0-rc.2 ([77890f4](https://github.com/kucherenko/jscpd/commit/77890f4))
* refactor: 💡 change imports in core package ([f33a412](https://github.com/kucherenko/jscpd/commit/f33a412))



## 3.3.0-rc.1 (2020-04-29)

* v3.3.0-rc.1 ([dd2a39d](https://github.com/kucherenko/jscpd/commit/dd2a39d))
* refactor: 💡 add new branch to git repo ([633a854](https://github.com/kucherenko/jscpd/commit/633a854))



