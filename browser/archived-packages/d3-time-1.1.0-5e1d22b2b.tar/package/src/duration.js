export var durationSecond = 1e3;
export var durationMinute = 6e4;
export var durationHour = 36e5;
export var durationDay = 864e5;
export var durationWeek = 6048e5;
