# Changelog

See [GitHub Releases][releases] for the changelog.

[releases]: https://github.com/unifiedjs/unified/releases
