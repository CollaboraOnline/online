
1.4.0 / 2015-07-15
==================

  * package: Add "license" attribute (#41, @pdehaan)
  * index: Allow other implementations of `document` (#39, @tomekwi)

1.3.3 / 2015-04-05
==================

  * update readme

1.3.2 / 2015-03-10
==================

  * add support for `<g>` svg elements

1.3.1 / 2014-07-16
==================

 * add script tag support for IE

1.3.0 / 2014-07-14
==================

 * index: allow an explicit `document` object to be passed in
 * index: update JSDoc comments
 * package: rename back to "domify"

1.2.2 / 2014-02-10
==================

  * package: rename to "component-domify"
  * package: update "main" and "component" fields
  * package: use 2 space tabs
  * component: remove redundant "scripts" array entry

1.2.1 / 2014-01-30
==================

 * fix leading/trailing whitespace in text nodes

1.2.0 / 2014-01-05
==================

 * add basic SVG element support [jkroso]

1.1.1 / 2013-11-05
==================

 * use createTextNode() [jkroso]

1.1.0 / 2013-11-05
==================

 * do not rely on live .children NodeList [timoxley]
 * generate text node if not given an html tag [timoxley]

1.0.0 / 2013-06-13
==================

 * return document fragments for multiple top level nodes

0.2.0 / 2013-05-21
==================

 * change to return an array at all times. Closes #7

0.1.0 / 2012-10-24
==================

  * add support for body elements with classes [timoxley]
  * add removal of dummy parent div [timoxley]
  * fix tests
  * fix Makefile

0.0.3 / 2012-08-28
==================

  * fix package.json

0.0.2 / 2012-08-01
==================

  * add support for <body> tags. Closes #1 [domenic]

0.0.1 / 2010-01-03
==================

  * Initial release
