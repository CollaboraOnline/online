import type {Vocabulary} from "../../types"
import formatKeyword from "./format"

const format: Vocabulary = [formatKeyword]

export default format
