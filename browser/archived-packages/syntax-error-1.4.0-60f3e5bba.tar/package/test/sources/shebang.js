#!/usr/bin/env node
console.log('foo');
