# @babel/helper-validator-identifier

> Validate identifier/keywords name

See our website [@babel/helper-validator-identifier](https://babeljs.io/docs/babel-helper-validator-identifier) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-validator-identifier
```

or using yarn:

```sh
yarn add @babel/helper-validator-identifier
```
