var a = { ...b }
