console.log([
  __dirname,
  __filename
]);
