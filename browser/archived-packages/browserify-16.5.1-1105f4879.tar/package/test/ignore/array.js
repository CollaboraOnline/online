t.deepEqual(require('./skip.js'), {});
t.deepEqual(require('./skip2.js'), {});
