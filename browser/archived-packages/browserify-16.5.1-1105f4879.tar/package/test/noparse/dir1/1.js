module.exports = {
    1: true,
    2: require('./dir2/2')
};
