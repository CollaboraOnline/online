# shasum

Single function that return the sha1sum.
Installing this is just a little bit quicker than reading the crypto documentation.

``` js
var shasum = require('shasum')
shasum(string || buffer || object)
```

Oh yeah, it works in the browser too, with [browserify](https://npmjs.org/package/browserify)

## License

MIT
