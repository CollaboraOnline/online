import EventEmitter from './index.js'

export { EventEmitter }
export default EventEmitter
