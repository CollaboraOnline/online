import transpose from "./transpose.js";

export default function() {
  return transpose(arguments);
}
