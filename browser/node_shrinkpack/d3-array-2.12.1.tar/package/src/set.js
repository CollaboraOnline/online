export default function set(values) {
  return values instanceof Set ? values : new Set(values);
}
