# shasum-object change log

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## 1.0.1
* Use strict mode.
* Testing and documentation improvements.

## 1.0.0
* Initial release.
