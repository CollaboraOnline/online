'use strict'

module.exports = bail

function bail(err) {
  if (err) {
    throw err
  }
}
