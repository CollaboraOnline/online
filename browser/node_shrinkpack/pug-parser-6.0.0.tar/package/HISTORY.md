2.0.1 / 2016-06-01
==================

  * Add a brief API introduction to README

2.0.0 / 2016-05-14
==================

  * Take the `filename` as an option rather than special casing it.  This means that parse only takes 2 arguments rather than 3
  * Add type checking on arguments
  * Treat the legacy `.jade` extension as `.pug` rather than a raw include
