export function byteLength(b64: string): number;
export function toByteArray(b64: string): Uint8Array;
export function fromByteArray(uint8: Uint8Array): string;
