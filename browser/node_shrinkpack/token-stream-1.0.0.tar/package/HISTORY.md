1.0.0 / 2016-06-01
==================

  * Update repo URL in `package.json`.
  * Mark as stable.
