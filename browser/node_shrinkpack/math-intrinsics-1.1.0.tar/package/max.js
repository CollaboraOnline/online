'use strict';

/** @type {import('./max')} */
module.exports = Math.max;
