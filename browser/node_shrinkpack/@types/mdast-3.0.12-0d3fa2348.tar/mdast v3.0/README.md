# Installation
> `npm install --save @types/mdast`

# Summary
This package contains type definitions for Mdast (https://github.com/syntax-tree/mdast).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast/v3.

### Additional Details
 * Last updated: Tue, 11 Jul 2023 16:02:42 GMT
 * Dependencies: [@types/unist](https://npmjs.com/package/@types/unist)
 * Global values: none

# Credits
These definitions were written by [Christian Murphy](https://github.com/ChristianMurphy), [Jun Lu](https://github.com/lujun2), [Remco Haszing](https://github.com/remcohaszing), and [Titus Wormer](https://github.com/wooorm).
