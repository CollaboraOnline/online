'use strict';

require('./app.css');
var foo = require('./modules/foo');
var bar = require('./modules/bar');

foo.init();
bar.init();
