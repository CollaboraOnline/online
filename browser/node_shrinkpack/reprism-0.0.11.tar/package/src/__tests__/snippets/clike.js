export default `// Single line comment
/* Multi-line
comment */

"foo \"bar\" baz";
'foo \'bar\' baz';

123
123.456
-123.456
1e-23
123.456E789
0xaf
0xAF


foo();
Bar();
_456();
`
