export default `
.foo {
  background: blue;
  color: red;
}

.bar {
  background: yello;
  color: green;
}
`
