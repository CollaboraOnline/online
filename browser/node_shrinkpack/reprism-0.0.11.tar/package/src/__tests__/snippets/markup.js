export default `<div>
<ul>
  <li className='foo' alt='bar' style="background: red;">
    Hello!
  </li>
</ul>
</div>`
