export declare function assertNever(value: never, errorMessage?: string): never;
export declare function assertNever(value: never, getErrorMessage?: (value: unknown) => string): never;
export declare function assertNever(value: never, noThrow?: boolean): never;
export default assertNever;
