# Installation
> `npm install --save @types/jqueryui`

# Summary
This package contains type definitions for jqueryui (http://jqueryui.com/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jqueryui.

### Additional Details
 * Last updated: Mon, 03 Mar 2025 10:02:29 GMT
 * Dependencies: [@types/jquery](https://npmjs.com/package/@types/jquery)

# Credits
These definitions were written by [Boris Yankov](https://github.com/borisyankov), [John Reilly](https://github.com/johnnyreilly), and [Dieter Oberkofler](https://github.com/doberkofler).
