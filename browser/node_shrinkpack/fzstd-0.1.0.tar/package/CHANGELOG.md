# 0.1.0
- Stable release
- Fixed TypeScript typings for ESM projects