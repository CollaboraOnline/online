# Installation
> `npm install --save @types/sizzle`

# Summary
This package contains type definitions for sizzle (https://sizzlejs.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sizzle.

### Additional Details
 * Last updated: Mon, 25 Aug 2025 20:35:28 GMT
 * Dependencies: none

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu).
