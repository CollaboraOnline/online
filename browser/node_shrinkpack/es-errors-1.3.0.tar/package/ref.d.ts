declare const ReferenceError: ReferenceErrorConstructor;

export = ReferenceError;
