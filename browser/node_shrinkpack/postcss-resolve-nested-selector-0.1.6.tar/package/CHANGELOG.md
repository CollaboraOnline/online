# Changes to PostCSS Resolve Nested Selector

### 0.1.6

- add `CHANGELOG.md`
- add repository url in `package.json`

### 0.1.5

- restore compat with extremely old node versions

### 0.1.4

- do not resolve `&` in attributes or strings
- do not resolve escaped `&`

### 0.1.3

- only split atrule prules by top level comma's.

