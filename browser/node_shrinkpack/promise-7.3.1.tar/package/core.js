'use strict';

module.exports = require('./lib/core.js');

console.error('require("promise/core") is deprecated, use require("promise/lib/core") instead.');
