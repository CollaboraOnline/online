// Minimum TypeScript Version: 3.0

import stream from './dist/stream'

export default stream
