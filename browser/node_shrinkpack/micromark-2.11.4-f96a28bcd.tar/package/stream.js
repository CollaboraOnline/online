'use strict'

module.exports = require('./dist/stream.js')
