// Minimum TypeScript Version: 3.0

import buffer from './dist'

export default buffer
