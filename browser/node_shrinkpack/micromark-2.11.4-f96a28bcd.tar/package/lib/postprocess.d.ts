import {Event} from './shared-types'

declare function postprocess(events: Event[]): Event[]

export default postprocess
