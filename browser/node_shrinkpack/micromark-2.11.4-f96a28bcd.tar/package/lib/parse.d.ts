import {ParseOptions, Parser} from './shared-types'

declare function createParser(options?: ParseOptions): Parser

export default createParser
