export default function() {
  return this._root;
}
