# Installation
> `npm install --save @types/mdast`

# Summary
This package contains type definitions for mdast (https://github.com/syntax-tree/mdast).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast/v3.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 20:08:00 GMT
 * Dependencies: [@types/unist](https://npmjs.com/package/@types/unist)

# Credits
These definitions were written by [Christian Murphy](https://github.com/ChristianMurphy), [Jun Lu](https://github.com/lujun2), [Remco Haszing](https://github.com/remcohaszing), and [Titus Wormer](https://github.com/wooorm).
