const Buffer = null;
t.equal(Buffer, null);
