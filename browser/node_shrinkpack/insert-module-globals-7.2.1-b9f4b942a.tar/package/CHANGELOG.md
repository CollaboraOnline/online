# insert-module-globals Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## 7.2.1
* Fix incorrect output when source contains a top-level `const` declaration with the same name as an inserted global. ([d86999f](https://github.com/browserify/insert-module-globals/commit/d86999f0180e09dd272666f5aff8db04183b3ea2))
