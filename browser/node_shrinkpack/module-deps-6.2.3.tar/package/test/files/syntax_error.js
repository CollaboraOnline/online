const a = require('a');
const a = 0;
