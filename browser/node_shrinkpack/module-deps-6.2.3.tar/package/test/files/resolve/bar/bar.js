var bar2 = require('./bar2');

module.exports = function () {
    return 'bar';
};