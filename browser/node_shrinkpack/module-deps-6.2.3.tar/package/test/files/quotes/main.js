var foo = require('./foo');
var bar = require("./bar");
var baz = require(`./baz`);
