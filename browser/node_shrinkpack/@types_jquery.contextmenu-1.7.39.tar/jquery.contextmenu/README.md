# Installation
> `npm install --save @types/jquery.contextmenu`

# Summary
This package contains type definitions for jquery.contextmenu (http://medialize.github.com/jQuery-contextMenu/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jquery.contextmenu.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/jquery.contextmenu/index.d.ts)
````ts
/// <reference types="jquery" />

interface JQueryContextMenuOptions {
    selector: string;
    appendTo?: string | undefined;
    trigger?: string | undefined;
    autoHide?: boolean | undefined;
    delay?: number | undefined;
    determinePosition?: ((menu: JQuery) => void) | undefined;
    position?: ((opt: JQueryContextMenuOptions & { $menu: JQuery }, x: number, y: number) => void) | undefined;
    positionSubmenu?: ((menu: JQuery) => void) | undefined;
    zIndex?: number | undefined;
    animation?: {
        duration?: number | undefined;
        show?: string | undefined;
        hide?: string | undefined;
    } | undefined;
    events?: {
        show?: ((options: any) => boolean) | undefined;
        hide?: ((options: any) => boolean) | undefined;
    } | undefined;
    callback?: ((key: any, options: any) => any) | undefined;
    items?: any;
    build?: ((triggerElement: JQuery, e: Event) => any) | undefined;
    reposition?: boolean | undefined;
    className?: string | undefined;
    itemClickEvent?: string | undefined;
}

interface JQueryStatic {
    contextMenu(options?: JQueryContextMenuOptions): JQuery;
    contextMenu(type: string, selector?: any): JQuery;
}

interface JQuery {
    contextMenu(options?: any): JQuery;
}

````

### Additional Details
 * Last updated: Tue, 29 Jul 2025 01:31:49 GMT
 * Dependencies: [@types/jquery](https://npmjs.com/package/@types/jquery)

# Credits
These definitions were written by [Natan Vivo](https://github.com/nvivo).
