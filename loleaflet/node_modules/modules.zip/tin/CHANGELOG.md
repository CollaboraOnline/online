0.5.0 / 2014-05-23
------------------
* added `\n` to end of file. Closes #13

0.4.0 / 2014-01-14
------------------
* added `--bump` See #12

0.3.2 / 2013-12-06
------------------
* check shouldn't fail if package file doesn't exist. Closes #9
* fix bug when keywords array didn't exist. Closes #10

0.3.1 / 2013-11-05
------------------
* Repo now is properly set in component.json if github url is passed. Closes #8

0.3.0 / 2013-11-04
------------------
* exit and output if can't parse a file
* added `--check` arg to verify if can parse files
* ensure that `name`, `version`, and `description` are on top

0.2.0 / 2013-11-01
------------------
* added `--create` flag, Closes #4

0.1.0 / 2013-10-14
------------------
* Output `main` according to component spec. Closes #2

0.0.2 / 2013-10-02
------------------
* fixed description bug. Closes #1
* fixed `scripts` bug for component.json

0.0.1 / 2013-10-01
------------------
* Initial release.
