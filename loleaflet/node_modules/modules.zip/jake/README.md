### Jake -- the JavaScript build tool for Node.js

[![Build Status](https://api.travis-ci.org/jakejs/jake.png)](https://travis-ci.org/mde/jake)

Documentation site at [http://jakejs.com](http://jakejs.com/)

### License

Licensed under the Apache License, Version 2.0
(<http://www.apache.org/licenses/LICENSE-2.0>)
