## 0.1.3

* The 'clicks' parameter is now called 'detail' because it is used
  outside of just double-clicking.

## 0.1.2

* Fixes keyboard events in Safari

## 0.1.1

* Fixes naming of modifier keys

## 0.1.0

* Add `mouseover` and `mouseout` events.

## 0.0.2

* Fixed jQuery plugin inclusion - now works properly without jQuery available.
