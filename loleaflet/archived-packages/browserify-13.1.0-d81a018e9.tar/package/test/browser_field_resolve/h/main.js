try { var x = require('./x.js') } catch (err) {}
console.log(x)
