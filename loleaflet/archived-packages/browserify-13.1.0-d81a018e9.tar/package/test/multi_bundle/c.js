var b = require('./b');
var a = require('./a');
t.equal(b, 'foo');
t.equal(a, 'bar');
