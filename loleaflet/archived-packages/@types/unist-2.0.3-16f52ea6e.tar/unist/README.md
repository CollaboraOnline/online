# Installation
> `npm install --save @types/unist`

# Summary
This package contains type definitions for non-npm package Unist ( https://github.com/syntax-tree/unist ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/unist

Additional Details
 * Last updated: Thu, 14 Feb 2019 18:10:46 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by bizen241 <https://github.com/bizen241>, Jun Lu <https://github.com/lujun2>, Hernan Rajchert <https://github.com/hrajchert>, Titus Wormer <https://github.com/wooorm>, Junyoung Choi <https://github.com/rokt33r>.
