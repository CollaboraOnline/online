declare const htmlTags: readonly string[];

export = htmlTags;
