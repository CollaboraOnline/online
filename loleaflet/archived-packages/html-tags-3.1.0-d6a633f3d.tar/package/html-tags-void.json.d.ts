declare const voidHtmlTags: readonly string[];

export = voidHtmlTags;
