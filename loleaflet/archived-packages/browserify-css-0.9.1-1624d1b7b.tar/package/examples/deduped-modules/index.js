'use strict';

var foo = require('foo');
var bar = require('bar');

foo.init();
bar.init();
