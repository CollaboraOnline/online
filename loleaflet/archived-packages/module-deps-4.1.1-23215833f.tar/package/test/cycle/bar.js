var foo = require('./foo.js');

module.exports = function (n) { return foo.p(n, 1) };
