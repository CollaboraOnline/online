t.equal(require('./'), 2);
