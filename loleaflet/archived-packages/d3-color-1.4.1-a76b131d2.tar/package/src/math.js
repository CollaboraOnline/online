export var deg2rad = Math.PI / 180;
export var rad2deg = 180 / Math.PI;
