# 0.7.1 (2016-03-11)

* fix bracket notation number parsing (de5d19)

# 0.7.0 (2015-10-17)

* add bracket notation support for hash serialization

# 0.6.0 (2015-02-23)

* add options.empty to force serialize empty inputs

# 0.5.0 (2015-02-08)

* fix specifying custom serializer

# 0.4.1 (2015-01-15)

* fix nested [][] serialization

# 0.4.0 (2014-12-16)

* consistently serialize [] params into arrays
* fix multi-select field support

# 0.3.0 / 2014-05-01

* support bracket notation for hash serialization

# 0.2.0 / 2013-12-05

* add `disabled` option to include disabled fields

# 0.1.1 / 2013-08-26
