"use strict";

// eslint-disable-next-line no-empty-function
module.exports = function () {};
