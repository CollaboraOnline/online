"use strict";

module.exports = {
	safeStringify: require("./safe-stringify")
};
