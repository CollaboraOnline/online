"use strict";

module.exports = require("./is-implemented")()
	? RegExp.prototype.replace
	: require("./shim");
