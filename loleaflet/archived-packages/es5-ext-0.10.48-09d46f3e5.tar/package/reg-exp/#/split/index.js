"use strict";

module.exports = require("./is-implemented")()
	? RegExp.prototype.split
	: require("./shim");
