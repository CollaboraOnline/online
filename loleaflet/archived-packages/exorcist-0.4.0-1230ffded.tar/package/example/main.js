'use strict';

var foo = require('./foo');

foo();
