'use strict';

var go = module.exports = function () {
  return 'hey, I am bar';    
};
