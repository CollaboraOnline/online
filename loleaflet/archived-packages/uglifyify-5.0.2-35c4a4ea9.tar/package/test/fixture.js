var hello = 'world'
if (hello !== 'world') {
  throw new Error
}
