CHANGELOG
=========

## 3.0.0

_breaking changes_

* Replace blank strings with about:blank
* Replace null values with about:blank

## 2.1.0
* Allow relative urls to be sanitized

## 2.0.2
* Sanitize malicious URLs that begin with `\s`

## 2.0.1
* Sanitize malicious URLs that begin with %20

## 2.0.0
* sanitize data: urls

## 1.0.0
* sanitize javascript: urls
