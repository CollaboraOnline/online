
1.4.1 / 2013-12-09
==================

 * add missing files to component.json

1.4.0 / 2013-XX-XX
==================

 * add source map generation

1.3.2 / 2013-10-18 
==================

 * fix whitespace and indentation in the Compressed compiler.
 * add @namespace support
 * add .stylesheet(node)

1.3.1 / 2013-06-02 
==================

 * fix output of rules with no declarations for Identity compiler
 * fix defaulting of options

1.3.0 / 2013-05-28 
==================

 * add ignoring of empty rulesets. Closes #7
 * add separate compilers
 * add @supports support
 * add @page compilation support
 * fix comment output. Closes #16
 * fix trailing ; with comments within rules
 * fix comment indentation

1.2.0 / 2013-05-21 
==================

 * add @document compilation. Closes #82

1.1.0 / 2013-03-19 
==================

  * add omission of comments when compressed
  * add comment support

1.0.5 / 2013-03-15 
==================

  * fix indentation of multiple selectors in @media. Closes #11

1.0.4 / 2012-11-15 
==================

  * fix indentation

1.0.3 / 2012-09-04 
==================

  * add __@charset__ support [rstacruz]

1.0.2 / 2012-09-01 
==================

  * add component support

1.0.1 / 2012-07-26 
==================

  * add "selectors" array support

0.0.1 / 2010-01-03
==================

  * Initial release
