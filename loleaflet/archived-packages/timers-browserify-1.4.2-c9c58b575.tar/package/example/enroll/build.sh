#!/bin/bash

browserify --debug -o js/browserify.js js/main.js
