import "transpose";

d3.zip = function() {
  return d3.transpose(arguments);
};
