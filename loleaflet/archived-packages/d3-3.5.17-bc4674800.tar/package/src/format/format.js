import "../locale/en-US";

d3.format = d3_locale_enUS.numberFormat;
