export default function(x) {
  return function constant() {
    return x;
  };
}
